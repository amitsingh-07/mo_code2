import { inject, TestBed } from '@angular/core/testing';

//import { GuideMeService } from './guide-me.service';
import { PortfolioService } from './portfolio.service';

describe('GuideMeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: []
    });
  });

  it('should be created', inject([PortfolioService], (service: PortfolioService) => {
    expect(service).toBeTruthy();
  }));
});
