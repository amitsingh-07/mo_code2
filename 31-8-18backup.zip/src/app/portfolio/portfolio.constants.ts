export let portfolioConstants = {
    my_financials : {
        sufficient_emergency_fund: "yes"
    }
};
