export class PersonalInfo {
        
    dateOfBirth: string;
        investmentPeriod:number;
    }
