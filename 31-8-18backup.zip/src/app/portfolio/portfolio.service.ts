import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { ApiService } from '../shared/http/api.service';
import { IMyFinancials } from './my-financials/my-financials.interface';
import { PersonalFormError } from './personal-info/personal-form-error';
import { PersonalInfo } from './personal-info/personal-info';
import { PortfolioFormData } from './portfolio-form-data';
const PORTFOLIO_RECOMMENDATION_COUNTER_KEY = 'portfolio_recommendation-counter';
const SESSION_STORAGE_KEY = 'app_session_storage_key';


@Injectable({
  providedIn: 'root'
})
export class PortfolioService {
  protectionNeedsPageIndex:0;
  selectedProtectionNeedsPage:any;
  
  
  
  private isProfileFormValid = false;
  private isProtectionNeedFormValid = false;
  private isLongTermCareFormValid = true;
  private isHospitalPlanFormValid = true;
  isMyIncomeFormValid = false;
  isMyExpensesFormValid = false;
  
  protectionNeedsArray: any;
  isMyOcpDisabilityFormValid = false;
  isExistingCoverAdded = false;

  // Variables for Insurance Results Generation
  private result_title: string;
  private result_icon: string;
  private result_value;

  private portfolioFormData: PortfolioFormData = new PortfolioFormData();
  private personalFormError: any = new PersonalFormError();
  //private myFinanacialFormError : any = new MyFinanacialFormError ();

  constructor(private http: HttpClient, private apiService: ApiService) {
  }

  getPortfolioFormData(): PortfolioFormData {
    let formData = this.portfolioFormData;
    //formData.dateOfBirth = formData.dateOfBirth.day
    return this.portfolioFormData;
  }


  //PERSONAL INFO
  getPersonalInfo() {
    return {
      dob: this.portfolioFormData.dateOfBirth,
      investmentPeriod:this.portfolioFormData.investmentPeriod
    };
  }
  currentFormError(form) {
    const invalid = [];
    const invalidFormat = []; 
    const controls = form.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalid.push(name);
        invalidFormat.push(Object.keys(controls[name]['errors']));
      }
    }
    return this.getFormError(invalid[0], invalidFormat[0][0]);
  } 
  getFormError(formCtrlName: string, validation: string): string {
    return this.personalFormError.formFieldErrors[formCtrlName][validation];
    
  }
  setUserInfo(data:PersonalInfo) {
    this.portfolioFormData.dateOfBirth = data.dateOfBirth;
    this.portfolioFormData.investmentPeriod=data.investmentPeriod;
    this.commit();
  }

  //RISK ASSESSMENT
  getQuestionsList() {
    return this.apiService.getQuestionsList();
  }
  getSelectedOptionByIndex(index){
    return this.portfolioFormData["riskAssessQuest" + index];
  }
  setRiskAssessment(data, questionIndex) {
    this.portfolioFormData["riskAssessQuest" + questionIndex] = data;
  }

  //MY FINANCIALS
  getMyFinancials(): IMyFinancials {
    return {
      monthlyIncome: this.portfolioFormData.monthlyIncome,
      percentageOfSaving: this.portfolioFormData.percentageOfSaving,
      totalAssets: this.portfolioFormData.totalAssets,
      totalLiabilities: this.portfolioFormData.totalLiabilities,
      initialInvestment: this.portfolioFormData.initialInvestment,
      monthlyInvestment: this.portfolioFormData.monthlyInvestment,
      suffEmergencyFund: this.portfolioFormData.suffEmergencyFund
    }; 
  }
  setMyFinancials(formData){
    this.portfolioFormData.monthlyIncome = formData.monthlyIncome;
    this.portfolioFormData.percentageOfSaving = formData.myIncomeSaved;
    this.portfolioFormData.totalAssets = formData.totalAssets;
    this.portfolioFormData.totalLiabilities = formData.totalLoans;
    this.portfolioFormData.initialInvestment = formData.initialInvestment;
    this.portfolioFormData.monthlyInvestment = formData.monthlyInvestment;
    this.portfolioFormData.suffEmergencyFund = formData.suffEmergencyFund;
    this.commit();
  }
  
  //SAVE FOR STEP 1
  savePersonalInfo(){
    const data = this.getPortfolioFormData();
    return this.apiService.savePersonalInfo(data);
    
  }
  // if () {
  //   return false;
  // } 
  // else {

  //   this.setInsuranceResultsModalCounter(0);
  //   return GUIDE_ME_ROUTE_PATHS.INSURANCE_RESULTS;
  // }

 setPortfolioRecommendationModalCounter(value: number) {
  if (window.sessionStorage) {
    sessionStorage.setItem(PORTFOLIO_RECOMMENDATION_COUNTER_KEY, value.toString());
    
  }
}

  getPortfolioRecommendationModalCounter() {
    return parseInt(sessionStorage.getItem(PORTFOLIO_RECOMMENDATION_COUNTER_KEY), 10);
   }
   
  commit() {
    if (window.sessionStorage) {
      sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(this.portfolioFormData));
    }
  }

}
 