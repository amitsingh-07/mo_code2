import { Component, OnInit } from '@angular/core';
import { PORTFOLIO_ROUTES, PORTFOLIO_ROUTE_PATHS } from '../portfolio-routes.constants';
import { PortfolioService } from './../portfolio.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-risk-profile',
  templateUrl: './risk-profile.component.html',
  styleUrls: ['./risk-profile.component.scss']
})
export class RiskProfileComponent implements OnInit {

  constructor(
    private router: Router,
    private portfolioService: PortfolioService
  ) { }

  ngOnInit() {
  }
  goToNext(form) {
    this.portfolioService.setPortfolioRecommendationModalCounter(0);
    this.router.navigate([PORTFOLIO_ROUTE_PATHS.PORTFOLIO_RECOMMENDATION])

  }
}
