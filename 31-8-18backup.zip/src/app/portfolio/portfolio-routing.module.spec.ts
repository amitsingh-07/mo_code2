//import { GuideMeRoutingModule } from './guide-me-routing.module';

import { PortfolioRoutingModule } from './portfolio-routing.module';

describe('GuideMeRoutingModule', () => {
  let guideMeRoutingModule: PortfolioRoutingModule;

  beforeEach(() => {
    guideMeRoutingModule = new PortfolioRoutingModule();
  });

  it('should create an instance', () => {
    expect(guideMeRoutingModule).toBeTruthy();
  });
});
