export interface ILifeProtectionNeedsData {
    coverageAmount: number;
    coverageDuration: number;
    isPremiumWaiver: boolean;
}
