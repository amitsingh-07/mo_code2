export class ProtectionNeeds {
    protectionTypeId: number;
    protectionType: string;
    protectionDesc: string;

    status: boolean;
}
