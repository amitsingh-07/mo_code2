export interface IMyOcpDisability {
    coverageAmount: number;
    maxAge: number;
    percentageCoverage: any;
    coverageDuration: number;
    employmentStatusId: number;
    selectedEmployee: string;
}
