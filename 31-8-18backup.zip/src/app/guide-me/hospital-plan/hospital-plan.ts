export class HospitalPlan {
    hospitalClass: string;
    hospitalClassDescription: string;
    hospitalClassId: number;
    isFullRider = false;
}
