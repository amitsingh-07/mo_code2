export interface IMyIncome {
    monthlySalary: number;
    annualBonus: number;
    otherIncome: number;
}
