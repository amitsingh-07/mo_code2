export class LongTermCare {
    careGiverType: string;
    careGiverDescription: string;
    careGiverTypeId: number;
    monthlyPayout = 0;
}
