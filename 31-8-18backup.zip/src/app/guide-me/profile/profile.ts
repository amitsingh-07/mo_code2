export class Profile {
    myProfile: number ;
}
