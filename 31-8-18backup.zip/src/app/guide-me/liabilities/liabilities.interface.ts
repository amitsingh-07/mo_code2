export interface IMyLiabilities {
    propertyLoan: number;
    carLoan: number;
    otherLoan: number;
}
