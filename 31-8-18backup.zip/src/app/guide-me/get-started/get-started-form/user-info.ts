export class UserInfo {
        gender: string ;
        dob: string;
        customDob: string;
        smoker: string;
        dependent: number;
    }
