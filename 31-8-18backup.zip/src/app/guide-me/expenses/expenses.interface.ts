export interface IMyExpenses {
    monthlyInstallments: number;
    livingExpenses: number;
    otherExpenses: number;
}
