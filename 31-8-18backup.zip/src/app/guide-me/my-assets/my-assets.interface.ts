export interface IMyAssets {
    cash: number;
    cpf: number;
    homeProperty: number;
    investmentProperties: number;
    otherInvestments: number;
    otherAssets: number;
}
