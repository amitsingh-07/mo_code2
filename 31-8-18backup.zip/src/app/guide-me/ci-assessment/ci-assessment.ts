export class CriticalIllnessData {
    coverageAmount: number;
    coverageYears: number;
    isEarlyCriticalIllness: false;

    annualSalary: number;
    ciMultiplier: number;
}
