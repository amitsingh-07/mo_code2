export interface IError {
    error: string[];
    message: string;
}
