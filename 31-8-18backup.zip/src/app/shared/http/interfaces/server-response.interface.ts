/**
 *
 * data: any;
 * error: string[];
 * message: string;
 */
export interface IServerResponse {
    responseMessage: any;
    objectList: any;
}
