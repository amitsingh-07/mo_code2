export abstract class Logger {
  error: any;
  info: any;
  warn: any;
}
