export const environment = {
  production: true,
  isDebugMode: false,
  apiBaseUrl: 'http://bfa-uat.ntuclink.cloud'
};
